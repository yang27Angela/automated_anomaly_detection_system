export async function preprocessImageBitmap(image: ImageBitmap): Promise<Float32Array> {
    const canvas = document.createElement("canvas");
    canvas.width = 640;
    canvas.height = 640;
    const ctx = canvas.getContext("2d")!;
    ctx.drawImage(image, 0, 0, 640, 640);
  
    const imageData = ctx.getImageData(0, 0, 640, 640);
    const { data } = imageData;
    const floatArray = new Float32Array(3 * 640 * 640);
  
    for (let i = 0; i < 640 * 640; i++) {
      floatArray[i] = data[i * 4] / 255.0;           // R
      floatArray[i + 640 * 640] = data[i * 4 + 1] / 255.0; // G
      floatArray[i + 2 * 640 * 640] = data[i * 4 + 2] / 255.0; // B
    }
  
    return floatArray;
  }
  