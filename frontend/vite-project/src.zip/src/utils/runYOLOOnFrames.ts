import * as ort from 'onnxruntime-web';
import { preprocessImageBitmap } from './preprocess';
ort.env.wasm.wasmPaths = '/public/ort-web/'; // 确保该路径指向你的 wasm 文件所在的目录

ort.env.wasm.numThreads = 1;
ort.env.wasm.simd = true;
const labels = [
    "person", "bicycle", "car", "motorcycle", "airplane", "bus", "train", "truck",
    "boat", "traffic light", "fire hydrant", "stop sign", "parking meter", "bench",
    "bird", "cat", "dog", "horse", "sheep", "cow", "elephant", "bear", "zebra",
    "giraffe", "backpack", "umbrella", "handbag", "tie", "suitcase", "frisbee",
    "skis", "snowboard", "sports ball", "kite", "baseball bat", "baseball glove",
    "skateboard", "surfboard", "tennis racket", "bottle", "wine glass", "cup",
    "fork", "knife", "spoon", "bowl", "banana", "apple", "sandwich", "orange",
    "broccoli", "carrot", "hot dog", "pizza", "donut", "cake", "chair", "couch",
    "potted plant", "bed", "dining table", "toilet", "tv", "laptop", "mouse",
    "remote", "keyboard", "cell phone", "microwave", "oven", "toaster", "sink",
    "refrigerator", "book", "clock", "vase", "scissors", "teddy bear",
    "hair drier", "toothbrush"
  ];
  
export async function runYOLOOnFrames(frames: ImageBitmap[]) {

    const session = await ort.InferenceSession.create('/models/yolov5n.onnx');
  
    const alerts = [];
  
    for (let i = 0; i < frames.length; i++) {
      const tensorData = await preprocessImageBitmap(frames[i]);
      const inputTensor = new ort.Tensor('float32', tensorData, [1, 3, 640, 640]);
  
      const feeds: Record<string, ort.Tensor> = {};
      feeds[session.inputNames[0]] = inputTensor;
      const results = await session.run(feeds);
  
      const output = results[session.outputNames[0]].data as Float32Array;
  
      const objects = parseYOLOOutput(output);
  
      const canvas = document.createElement('canvas');
      canvas.width = frames[i].width;
      canvas.height = frames[i].height;
      const ctx = canvas.getContext('2d')!;
      ctx.drawImage(frames[i], 0, 0);
      const frame_url = canvas.toDataURL('image/png');
  
      // Format message to include both the object and its confidence
      const objectStrings = objects.map(obj => `${obj.object} (conf: ${obj.confidence})`);
      const message = `Detected: ${objectStrings.join(', ')}`;
  
      alerts.push({
        timestamp: `00:00:0${i}`,
        alertType: 'YOLO Detection',
        message, // Now includes both object and confidence
        frame_url,
        details: objects // Details can still include all object information
      });
    }
  
    return alerts;
  }
  

// Function to parse the output of the YOLO model
function parseYOLOOutput(output: Float32Array) {
    const boxes = [];
    const numDetections = output.length / 85; // Each detection consists of 85 values
  
   
  
    // Create an array to store the detected objects with their scores
    const detections = [];
  
    for (let i = 0; i < numDetections; i++) {
      const offset = i * 85; // Offset for each detection
      const scores = output.slice(offset + 5, offset + 85); // Get the scores for each class
  
    
  
      const maxScore = Math.max(...scores); // Find the max score
      const classId = scores.findIndex(s => s === maxScore); // Find the index of the class with the max score
  
      
  
      // If the max score is above a certain threshold (0.5), save this detection
      if (maxScore > 0.5) {
        // Ensure classId is within the range of labels
        const objectLabel = labels[classId] || 'Unknown Object'; // Default to 'Unknown Object' if out of range
       
        detections.push({
          object: objectLabel, // Use the label for the detected object
          confidence: maxScore // Use the max score as confidence
        });
      }
    }
  
    // Now remove duplicates and keep only the highest confidence for each object
    const uniqueDetections = detections.reduce((acc, detection) => {
      const existing = acc.find(d => d.object === detection.object);
      if (!existing || existing.confidence < detection.confidence) {
        if (existing) {
          // Remove the previous lower confidence detection
          const index = acc.indexOf(existing);
          acc.splice(index, 1);
        }
        acc.push(detection);
      }
      return acc;
    }, []);
  
    return uniqueDetections; // Return the final detections with highest confidence for each object
  }