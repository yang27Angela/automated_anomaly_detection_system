// src/utils/alertService.ts
import axios from 'axios';
import db from '../db';

export interface Alert {
  timestamp: string;
  type: string;
  message: string;
  frame: string; // base64 encoded image string
  details: Record<string, any>;
}

export async function submitAlert(alert: Alert) {
  try {
    const res = await axios.post(`${import.meta.env.VITE_API_URL}/alerts`, alert);
    return res.data;
  } catch (error) {
    console.error('Failed to submit alert:', error);
    throw error;
  }
}
export const updateAlert = async (id: string, newData: any) => {
  await db.query(
    "UPDATE alerts SET message = ? WHERE id = ?",
    [newData.message, id]
  );
};

export const deleteAlert = async (id: string) => {
  await db.query("DELETE FROM alerts WHERE id = ?", [id]);
};
