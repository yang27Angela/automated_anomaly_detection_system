export function generateAlertsFromFrames(frames: any[]) {
  return frames.map((frame, i) => {
    if (!(frame instanceof ImageBitmap)) {
      console.warn(`[skip] Frame ${i} is not an ImageBitmap`, frame);
      return null; // or skip entirely
    }

    const canvas = document.createElement('canvas');
    canvas.width = frame.width;
    canvas.height = frame.height;
    const ctx = canvas.getContext('2d')!;
    ctx.drawImage(frame, 0, 0);

    const dataUrl = canvas.toDataURL('image/png');

    return {
      timestamp: `00:00:0${i}`,
      alertType: 'Mock Anomaly',
      message: `Anomaly at frame ${i + 1}`,
      frame_url: dataUrl,
      details: [
        {
          object: i % 2 === 0 ? 'Person' : 'Car',
          confidence: 0.9
        }
      ]
    };
  }).filter(Boolean); // ✅ 去掉 null
}
