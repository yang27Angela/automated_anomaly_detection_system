import React from 'react';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow
} from '@mui/material';

type Alert = {
  timestamp: string;
  created_at: string; // 添加 created_at 字段
  alertType: string;
  message: string;
  frame_url: string;
};

export default function AlertTable({
  alerts,
  onSelect
}: {
  alerts: Alert[];
  onSelect: (alert: Alert) => void;
}) {
  console.log('[UI] Rendering table with', alerts.length, 'alerts');

  return (
    <Table>
      <TableHead>
        <TableRow>
          <TableCell>Timestamp</TableCell>
          <TableCell>Created At</TableCell> {/* 新增 Created At 列 */}
          <TableCell>Type</TableCell>
          <TableCell>Message</TableCell>
          <TableCell>Preview</TableCell>
        </TableRow>
      </TableHead>
      <TableBody>
        {alerts.map((a, i) => (
          <TableRow key={i} hover onClick={() => onSelect(a)} style={{ cursor: 'pointer' }}>
            <TableCell>{a.timestamp}</TableCell>
            <TableCell>{a.created_at}</TableCell> {/* 显示 created_at */}
            <TableCell>{a.alertType}</TableCell>
            <TableCell>{a.message}</TableCell>
            <TableCell>
              <img
                src={a.frame_url || a.frame}
                alt="frame"
                style={{ height: 60 }}
              />
            </TableCell>
          </TableRow>
        ))}
      </TableBody>
    </Table>
  );
}
