import React, { useState } from 'react';
import {
  Typography, CircularProgress, Snackbar, Alert,
  TextField, Checkbox, FormControlLabel, Button
} from '@mui/material';
import AlertTable from '../components/AlertTable';
import AlertDetailDialog from '../components/AlertDetailDialog';
import { extractFramesFromVideo } from '../utils/frameExtractor';
import { runYOLOOnFrames } from '../utils/runYOLOOnFrames';

export default function MainPage() {
  const [alerts, setAlerts] = useState<any[]>([]);
  const [selectedAlert, setSelectedAlert] = useState<any | null>(null);
  const [loading, setLoading] = useState(false);
  const [snackbarMessage, setSnackbarMessage] = useState('');
  const [search, setSearch] = useState('');
  const [requirePerson, setRequirePerson] = useState(false);
  const [requireCar, setRequireCar] = useState(false);

  const handleUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setLoading(true);
    try {
      const frames = await extractFramesFromVideo(file);
      const generated = await runYOLOOnFrames(frames);
      setSnackbarMessage('✅ Alerts generated and uploading...');

      // 这里你可以确保生成的 alert 包含 created_at 字段
      const alertsWithCreatedAt = generated.map((alert: any) => ({
        ...alert,
        created_at: new Date().toISOString() // 使用当前时间作为 created_at
      }));

      const res = await fetch('/api/alerts/upload', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ alerts: alertsWithCreatedAt })
      });

      const data = await res.json();
      console.log("[upload result]", data);

      setAlerts(alertsWithCreatedAt); // 更新 alerts
      setSnackbarMessage('✅ Alerts uploaded and shown');
    } catch (err: any) {
      console.error(err);
      setSnackbarMessage(`❌ Failed: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  const filteredAlerts = alerts?.filter((a) => {
    const matchSearch = !search ||
      a.message?.toLowerCase().includes(search.toLowerCase()) ||
      a.alertType?.toLowerCase().includes(search.toLowerCase());

    const hasPerson = a.details?.some((d: any) =>
      d.object?.toLowerCase() === 'person') ?? false;

    const hasCar = a.details?.some((d: any) =>
      d.object?.toLowerCase() === 'car') ?? false;

    return matchSearch && (!requirePerson || hasPerson) && (!requireCar || hasCar);
  }) || [];

  return (
    <div style={{ padding: 20 }}>
      <Typography variant="h4">Upload Video</Typography>
      <input type="file" accept="video/*" onChange={handleUpload} />
      {loading && <CircularProgress />}
      <TextField
        label="Search"
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        style={{ marginTop: 16, marginBottom: 8 }}
      />
      <FormControlLabel
        control={<Checkbox checked={requirePerson} onChange={(e) => setRequirePerson(e.target.checked)} />}
        label="Require Person"
      />
      <FormControlLabel
        control={<Checkbox checked={requireCar} onChange={(e) => setRequireCar(e.target.checked)} />}
        label="Require Car"
      />
      <Button onClick={() => window.location.href = '/history'}>View History</Button>
      <AlertTable alerts={filteredAlerts} onSelect={setSelectedAlert} />
      <AlertDetailDialog
        open={!!selectedAlert}
        alert={selectedAlert}
        onClose={() => setSelectedAlert(null)}
        readOnly={true}
      />
      <Snackbar open={!!snackbarMessage} autoHideDuration={4000} onClose={() => setSnackbarMessage('')}>
        <Alert severity="info">{snackbarMessage}</Alert>
      </Snackbar>
    </div>
  );
}
