import { Request, Response } from 'express';
import multer from 'multer';
const upload = multer();

export const uploadVideo = async (req: Request, res: Response) => {
  try {
    // Placeholder for future backend-based processing
    res.status(200).json({ message: 'Video received (noop).' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Upload failed' });
  }
};