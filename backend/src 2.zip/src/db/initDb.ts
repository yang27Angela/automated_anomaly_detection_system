// initDb.ts
import mysql from 'mysql2/promise';

async function initDb() {
  const db = await mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: ''
  });

  await db.query(`CREATE DATABASE IF NOT EXISTS anomaly_system`);
  await db.query(`USE anomaly_system`);
  await db.query(`
    CREATE TABLE IF NOT EXISTS alerts (
      id INT AUTO_INCREMENT PRIMARY KEY,
      timestamp VARCHAR(20),
      alert_type VARCHAR(50),
      message TEXT,
      frame_url TEXT,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
  `);

  console.log('✅ Database and table initialized');
  await db.end();
}

initDb();
