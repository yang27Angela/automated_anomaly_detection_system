import express from 'express';
const router = express.Router();

router.post('/upload', async (req, res) => {
  console.log('[UPLOAD] ✅ Received POST /api/upload');  // 👈 加在最开头！

  try {
    const { alerts } = req.body;

    if (!alerts || !Array.isArray(alerts)) {
      console.log('[UPLOAD] ❌ Invalid alerts:', alerts);
      return res.status(400).json({ success: false, message: 'Invalid alerts data' });
    }

    console.log('[UPLOAD] ✅ Valid alerts received:', alerts.length);

    // 你可以在这里添加数据库存储逻辑

    return res.status(201).json({
      success: true,
      savedAlerts: alerts
    });
  } catch (err) {
    console.error('[UPLOAD ERROR]', err);
    return res.status(500).json({ success: false, message: 'Internal server error' });
  }
});

export default router;
